self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "72d2135beb07e8a6a9e43b700160284b",
    "url": "/index.html"
  },
  {
    "revision": "d12e02fe99621ce7cdbc",
    "url": "/static/js/2.0d7ce3ba.chunk.js"
  },
  {
    "revision": "4d92265ee4745234cbf941e19ca6c02e",
    "url": "/static/js/2.0d7ce3ba.chunk.js.LICENSE.txt"
  },
  {
    "revision": "db15faa65f4ed9c3e3f3",
    "url": "/static/js/main.1c3b488a.chunk.js"
  },
  {
    "revision": "5cc8d2ec213dfdc1c6af",
    "url": "/static/js/runtime-main.b78fadcc.js"
  },
  {
    "revision": "f8e7d99ae8f0718500322e6fbd5f9ee2",
    "url": "/static/media/TronLinkLogo.f8e7d99a.png"
  }
]);